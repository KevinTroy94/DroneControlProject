package com.example.joysticktest;

public class Rolling {

    int size;
    double total = 0;
    int numEntries = 0;

    public Rolling(int size) {
        this.size = size;
    }

    public void add(double x) {
        if(this.numEntries < 100) {
            total += x;
        }
        numEntries ++;
    }
    public double getAverage() {
        double avg = (total / numEntries);
        return avg;
    }
}
