package com.example.joysticktest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.NotificationChannel;
import android.app.NotificationManager;


import com.zerokol.views.joystickView.JoystickView;
import com.zerokol.views.joystickView.JoystickView.OnJoystickMoveListener;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;


import android.os.Bundle;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MqttCallbackExtended {

    /*private TextView angleTextView;
    private TextView powerTextView;
    private TextView directionTextView;*/ //not necessary
    // Importing also other views
    private JoystickView joystick;
    private final static String CHANNEL_ID = "com.example.joysticktest.notifchannel";
    private final static int NOTIFICATION_ID = 1;

    //private final static String MQTT_HOST = "tcp://broker.hivemq.com:1883"; //this is broker
    private final static String MQTT_HOST = "tcp://broker.emqx.io:1883"; //this is broker
    private final static String TOPIC = "droneCommand/value"; //topic //topic
    private final static String TOPICFORMAT = "formationRequestTopic";
    private final static String TOPICASSIGN = "formationAssignTopic";
    private final static String TAG = "";
    private SharedPreferences droneLog;
    private int numDrones = 0;
    private Spinner dropdown;

    MqttAndroidClient androidClient;
    private TextView connectTv, newMessageTV, formationTV;

    long myTime = System.currentTimeMillis();

    private ArrayList<Drone> droneArrayList = new ArrayList<Drone>();

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        droneLog = getApplicationContext().getSharedPreferences("numDrones", MODE_PRIVATE);
        SharedPreferences.Editor editor = droneLog.edit();
        editor.putInt("numDrones", 0);
        connectTv = findViewById(R.id.connection_tv);
        newMessageTV = findViewById(R.id.new_message_tv);
        formationTV = findViewById(R.id.formation);

        String clientId = MqttClient.generateClientId(); //creates client id
        //client
        androidClient = new MqttAndroidClient(this,MQTT_HOST,clientId);

        //callback
        androidClient.setCallback(this);

        createdNotificationChannel();

        dropdown = findViewById(R.id.spinner);
        //create a list of items for the spinner.
        final String[] items = new String[]{"0", "1", "2", "3"};
        //create an adapter to describe how the items are displayed, adapters are used in several places in android.
        //There are multiple variations of this, but this is the basic variant.
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        //set the spinners adapter to the previously created one.
        dropdown.setAdapter(adapter);

        final MediaPlayer mpDrone = MediaPlayer.create(this, R.raw.dronetakeoff);

        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                mpDrone.start();
                numDrones = Integer.parseInt(items[position].toString());
                checkDroneNum();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        //angleTextView = (TextView) findViewById(R.id.angleTextView);
        //powerTextView = (TextView) findViewById(R.id.powerTextView);
        //directionTextView = (TextView) findViewById(R.id.directionTextView);
        //Referencing also other views
        joystick = (JoystickView) findViewById(R.id.joystickView);

        //Event listener that always returns the variation of the angle in degrees, motion power in percentage and direction of movement
        joystick.setOnJoystickMoveListener(new OnJoystickMoveListener() {

            @Override
            public void onValueChanged(int angle, int power, int direction) {
                // TODO Auto-generated method stub
                //angleTextView.setText(" " + String.valueOf(angle) + "°");
                //powerTextView.setText(" " + String.valueOf(power) + "%");
                //this is what happens when the joystick is pulled
                String message;
                switch (direction) {
                    case JoystickView.FRONT:
                        //directionTextView.setText(R.string.front_lab);
                        message = "Moving up at : " + System.currentTimeMillis();
                        publish(TOPIC,message);
                        break;
                    case JoystickView.FRONT_RIGHT:
                        //directionTextView.setText(R.string.front_right_lab);
                        break;
                    case JoystickView.RIGHT:
                        //directionTextView.setText(R.string.right_lab);
                        message = "Moving Left at : " + System.currentTimeMillis();
                        publish(TOPIC,message);
                        break;
                    case JoystickView.RIGHT_BOTTOM:
                        //directionTextView.setText(R.string.right_bottom_lab);
                        break;
                    case JoystickView.BOTTOM:
                        //directionTextView.setText(R.string.bottom_lab);
                        message = "Moving Down at : " + System.currentTimeMillis();
                        publish(TOPIC,message);
                        break;
                    case JoystickView.BOTTOM_LEFT:
                        //directionTextView.setText(R.string.bottom_left_lab);
                        break;
                    case JoystickView.LEFT:
                        //directionTextView.setText(R.string.left_lab);
                        message = "Moving Right at : " + System.currentTimeMillis();
                        publish(TOPIC,message);
                        break;
                    case JoystickView.LEFT_FRONT:
                        break;
                    default:
                        //directionTextView.setText(R.string.center_lab);
                }
            }
        }, JoystickView.DEFAULT_LOOP_INTERVAL);
    }

    @Override
    protected void onPostResume(){
        super.onPostResume();
        connect();
    }

    public void checkDroneNum(){
        //numDrones = droneLog.getInt("numDrones", 0);
        if (numDrones == 1) {
            formationTV.setText("Single Drone Formation");
            sendNotification(numDrones);
        }
        else if (numDrones == 2) {
            formationTV.setText("Double Drone Formation");
            sendNotification(numDrones);
        }
        else if (numDrones == 3) {
            formationTV.setText("Triple Drone Formation");
            sendNotification(numDrones);
        }
        else if (numDrones > 3) {
            formationTV.setText("Too many drones");
            sendNotification(numDrones);
        }
        else{
            formationTV.setText("No drones found");
        }
    }

    private void connect(){
        //create MQTT CONNECTION OPTIONS
        MqttConnectOptions connectOptions = new MqttConnectOptions();
        connectOptions.setAutomaticReconnect(true);
        connectOptions.setCleanSession(true);
        //connectOptions.setPassword(); not necessary for testing
        //connectOptions.setUserName(); not necessary for testing
        connectOptions.setConnectionTimeout(3);
        connectOptions.setKeepAliveInterval(60);

        try {
            androidClient.connect(connectOptions, null, new IMqttActionListener(){
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    DisconnectedBufferOptions options = new DisconnectedBufferOptions();
                    options.setBufferEnabled(true);
                    options.setBufferSize(100);
                    options.setPersistBuffer(false);
                    options.setDeleteOldestMessages(false);
                    androidClient.setBufferOpts(options);
                    connectTv.setText("Connected");
                    subscribe(TOPIC);
                    subscribeWithQos(TOPICFORMAT, 2);
                    //subscribe(TOPICFORMAT);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    connectTv.setText(String.format("Connection Failed.\n%s",exception.getMessage())); //uses a placeholder this way
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    private void subscribe(final String topic) {

        //this is the subscribe method, called on connect
        try {
            androidClient.subscribe(topic, 0, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //Log.d(TAG, "onSuccess: topic subscription : " + topic);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //Log.d(TAG, "onFailure: topic subscription : " + topic, exception);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

    }

    private void subscribeWithQos(final String topic,final int QOS) {

        //this is the subscribe method, called on connect
        try {
            androidClient.subscribe(topic, QOS, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //Log.d(TAG, "onSuccess: topic subscription : " + topic);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //Log.d(TAG, "onFailure: topic subscription : " + topic, exception);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

    }

    public void fly(View view){
        String message = "FORMATION ATTEMPT";
        if(numDrones == 0){
            //Toast.makeText(this, "NO drones to format", Toast.LENGTH_SHORT).show();
            /*Intent i = new Intent(this,singleDroneFormation.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_left,R.transition.slide_out_right);*/
        }
        if(numDrones == 1){
            //message = "SINGLE FORMATION COMMAND RECEIVED AT : " + System.currentTimeMillis();
            Intent i = new Intent(this,singleDroneFormation.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_left,R.transition.slide_out_right);
        }
        if(numDrones == 2){
            //message = "DOUBLE FORMATION COMMAND RECEIVED AT : " + System.currentTimeMillis();
            Intent i = new Intent(this,doubleDroneFormation.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_left,R.transition.slide_out_right);
        }
        if(numDrones == 3){
            //message = "TRIPLE FORMATION COMMAND RECEIVED AT : " + System.currentTimeMillis();
            Intent i = new Intent(this,tripleDroneFormation.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_left,R.transition.slide_out_right);
        }
        //publish(TOPIC,message);
    }

    private void publish(String topic, String stringMessage){
        MqttMessage message = new MqttMessage();
        message.setPayload(stringMessage.getBytes());

        try {
            androidClient.publish(topic, message);

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void connectComplete(boolean reconnect, String serverURI)
    {
        Log.d(TAG, "Connection Complete - MQTT");
    }

    @Override
    public void connectionLost(Throwable cause) {
        Log.d(TAG, "ConnectionLost - MQTT");
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        //will use
        //formationTV.setText(topic);
        if(TOPIC.equals(TOPIC)){
            byte[] bytes = message.getPayload();
            String stringMessage = new String(bytes, StandardCharsets.UTF_8);
            //
        }
        if(topic.equals(TOPICFORMAT)){
            byte[] bytes = message.getPayload();
            String stringMessage = new String(bytes, StandardCharsets.UTF_8);
            if(stringMessage.equals("Find Me A Formation")) {
                newMessageTV.setText("Finding Formation");
                numDrones++;
                droneArrayList.add(new Drone(numDrones));
                SharedPreferences.Editor editor = droneLog.edit();
                editor.putInt("numDrones",numDrones);
                numDrones = droneArrayList.size();

                publish(TOPICASSIGN, ""+numDrones);
                if (numDrones == 1) {
                    formationTV.setText("Single Drone Formation");
                    sendNotification(numDrones);
                }
                if (numDrones == 2) {
                    formationTV.setText("Double Drone Formation");
                    sendNotification(numDrones);
                }
                if (numDrones == 3) {
                    formationTV.setText("Triple Drone Formation");
                    sendNotification(numDrones);
                }
                if (numDrones > 3) {
                    formationTV.setText("Too many drones");
                    sendNotification(numDrones);
                }
                editor.putInt("numDrones", numDrones);
                editor.commit();
            }

            else {
                newMessageTV.setText(stringMessage);
            }
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }

    private void createdNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "notifChannel";
            String description = "ChennelForNotifs";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,name,importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void sendNotification(int n) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this,CHANNEL_ID);
        builder.setSmallIcon(R.drawable.drone_vector);
        Bitmap largeIcon = BitmapFactory.decodeResource(getResources(),R.drawable.drone_vector);
        builder.setLargeIcon(largeIcon);
        builder.setContentTitle("Drone");
        builder.setContentText("New Drone Connected, total drones: " + n);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);

        notificationManagerCompat.notify(NOTIFICATION_ID, builder.build());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_proj, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.Main) {
            //Go Back to main activity
            Intent i = new Intent(this,MainActivity.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_right,R.transition.slide_out_left);

        }
        if (id == R.id.Latency) {
            Intent i = new Intent(this,Latency.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_right,R.transition.slide_out_left);
        }

        return super.onOptionsItemSelected(item);
    }
    public void finish() {
        super.finish();
        overridePendingTransition(R.transition.slide_in_left,R.transition.slide_out_right);
    }

}
