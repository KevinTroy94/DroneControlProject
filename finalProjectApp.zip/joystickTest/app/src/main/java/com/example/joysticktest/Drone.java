package com.example.joysticktest;

public class Drone {
    int index;

    public Drone(int i) {

        this.index = i;
    }

    public int getIndex(){
        return this.index;
    }

    public void setIndex(int i){
        this.index = i;
    }

}
