package com.example.joysticktest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
import java.util.Random;

public class Latency extends AppCompatActivity implements MqttCallbackExtended {

    private final static String MQTT_HOST = "tcp://broker.emqx.io:1883"; //this is broker
    private final static String TOPIC = "DroneCommand/latency"; //topic //topic
    private final static String TOPICLATENCYREPLY = "DroneCommand/latencyReply"; //topic
    private final static String TOPICANDROIDLATENCYREPLY = "DroneCommand/androidlatencyReply"; //topi
    private final static String TAG = "MQTTSTATUS";
    MqttAndroidClient androidClient;
    long myTime = System.currentTimeMillis();
    long yourTime, myNewTime, yourNewTime;
    private LineChart chart;
    private TextView latencyTV, bluetoothLatencyTV;
    private Rolling mqttRolling, bluetoothRolling;
    private double mqttAvgLatency, bluetoothAvgLatency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.latency_layout);

        String clientId = MqttClient.generateClientId(); //creates client id
        //client
        androidClient = new MqttAndroidClient(this,MQTT_HOST,clientId);
        latencyTV = findViewById(R.id.LatencyTV);
        bluetoothLatencyTV = findViewById(R.id.RollingBluetoothTV);

        mqttRolling = new Rolling(1000);
        bluetoothRolling = new Rolling(1000);

        //callback
        androidClient.setCallback(this);

        chart = findViewById(R.id.chart1);
        chart.setDrawGridBackground(false);
        chart.getDescription().setEnabled(false);
        chart.setNoDataText("Waiting for Latency Data");

        chart.invalidate();

        /*Thread splashTread = new Thread() {

            public void run() {
                while (true) {


                    try {
                        sleep(4000);
                        //final float currentTemp = Float.parseFloat(tempData.getString("tempData", null));
                        addEntry(4000);
                        //change thing here

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }
        };
        splashTread.start();*/
    }

    private void connect(){
        //create MQTT CONNECTION OPTIONS
        MqttConnectOptions connectOptions = new MqttConnectOptions();
        connectOptions.setAutomaticReconnect(true);
        connectOptions.setCleanSession(true);
        //connectOptions.setPassword(); not necessary for testing
        //connectOptions.setUserName(); not necessary for testing
        connectOptions.setConnectionTimeout(3);
        connectOptions.setKeepAliveInterval(60);

        try {
            androidClient.connect(connectOptions, null, new IMqttActionListener(){
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    DisconnectedBufferOptions options = new DisconnectedBufferOptions();
                    options.setBufferEnabled(true);
                    options.setBufferSize(100);
                    options.setPersistBuffer(false);
                    options.setDeleteOldestMessages(false);
                    androidClient.setBufferOpts(options);
                    latencyTV.setText("Connected");
                    bluetoothLatencyTV.setVisibility(View.INVISIBLE);
                    subscribe(TOPIC);
                    //subscribe("formationRequestTopic");
                    subscribe(TOPICLATENCYREPLY);
                    //subscribe to latency check topics
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    latencyTV.setText(String.format("Connection Failed.\n%s",exception.getMessage())); //uses a placeholder this way

                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onPostResume(){
        super.onPostResume();
        connect();
    }

    private void subscribe(final String topic) {

        //this is the subscribe method, called on connect
        try {
            androidClient.subscribe(topic, 0, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //Log.d(TAG, "onSuccess: topic subscription : " + topic);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //Log.d(TAG, "onFailure: topic subscription : " + topic, exception);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

    }

    private void publish(String topic, String stringMessage){
        MqttMessage message = new MqttMessage();
        message.setPayload(stringMessage.getBytes());

        if(topic.equals(TOPICANDROIDLATENCYREPLY)){
            Toast.makeText(this, "sendinglatencyReply", Toast.LENGTH_SHORT).show();
        }

        try {
            androidClient.publish(topic, message);

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void connectComplete(boolean reconnect, String serverURI)
    {
        Log.d(TAG, "Connection Complete - MQTT");
    }

    @Override
    public void connectionLost(Throwable cause) {
        Log.d(TAG, "ConnectionLost - MQTT");
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        //will use
        if(topic.equals(TOPIC)){
            byte[] bytes = message.getPayload();
            String stringMessage = new String(bytes, StandardCharsets.UTF_8);
            //do things here
            //latencyTV.setText(stringMessage);
        }
        if(topic.equals(TOPICLATENCYREPLY)) {

            byte[] bytes = message.getPayload();
            String stringMessage = new String(bytes, StandardCharsets.UTF_8);

            //do things here
            //myTime = System.currentTimeMillis();
            //latencyTV.setText(stringMessage);

            myNewTime = System.currentTimeMillis();
            long timeDiff = calculateLatency(myNewTime);
            addEntry(timeDiff);

            mqttAvgLatency = mqttRolling.getAverage();
            bluetoothAvgLatency = bluetoothRolling.getAverage();

            String formattedMQTT = String.format("%.3f", mqttAvgLatency);
            String formattedBluetooth = String.format("%.3f", bluetoothAvgLatency);

            latencyTV.setText("Rolling average MQTT delay is : " + formattedMQTT + "ms");
            latencyTV.setTextColor(Color.rgb(240, 99, 99));
            bluetoothLatencyTV.setText("Rolling average BT delay is: "+ formattedBluetooth + "ms");
            bluetoothLatencyTV.setTextColor(Color.rgb(40, 99, 240));

            //yourTime = Long.parseLong(stringMessage);
            //long timeDiff = myTime - yourTime;
            //publish(TOPICANDROIDLATENCYREPLY, stringMessage); doesnt work for some reason
        }
    }

    public void publishMessageOnClick(View view){
        String message = "LatencyCheck";
        myTime = System.currentTimeMillis();
        bluetoothLatencyTV.setVisibility(View.VISIBLE);
        publish(TOPIC,message);
    }

    public long calculateLatency(long x){
        long latency = (Math.abs(myTime - x));
        //Toast.makeText(this, "diff is " + latency, Toast.LENGTH_SHORT).show();
        return latency;
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        Log.d(TAG, "Message Delivery Complete - MQTT");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_proj, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.Main) {
            //Go Back to main activity
            Intent i = new Intent(this,MainActivity.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_right,R.transition.slide_out_left);

        }
        if (id == R.id.Latency) {
            Intent i = new Intent(this,Latency.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_right,R.transition.slide_out_left);
        }

        return super.onOptionsItemSelected(item);
    }

    public float simulateBluetoothLatency(){

        final int min = 34; //ideal bluetooth latency
        final int max = 300; // highest tolerable bluetooth latency
        final float simulatedLatency = 2*(new Random().nextInt((max - min) + 1) + min);
        return simulatedLatency;
    }

    private void addEntry(float input) {

        LineData data = chart.getData();

        if (data == null) {
            data = new LineData();
            chart.setData(data);
        }

        ILineDataSet set = data.getDataSetByIndex(0); //this is where to go if you want more lines
        ILineDataSet bluetoothSet = data.getDataSetByIndex(1); //this is where to go if you want more lines

        if (set == null) {
            set = createSet();
            data.addDataSet(set);
        }
        if (bluetoothSet == null) {
            bluetoothSet = createSet2();
            data.addDataSet(bluetoothSet);
        }

        // choose a random dataSet
        //int SetIndex = (int) data.getDataSetCount();

        float value = (float) (input);
        mqttRolling.add(value);
        float BluetoothLatency = simulateBluetoothLatency();
        bluetoothRolling.add(BluetoothLatency);

        data.addEntry(new Entry(set.getEntryCount(), value), 0);
        data.addEntry(new Entry(bluetoothSet.getEntryCount(), BluetoothLatency), 1);


        data.notifyDataChanged();

        // let the chart know it's data has changed
        chart.notifyDataSetChanged();

        chart.setVisibleXRangeMaximum(6);
        //chart.setVisibleYRangeMaximum(15, AxisDependency.LEFT);
//
//            // this automatically refreshes the chart (calls invalidate())
        chart.moveViewTo(data.getEntryCount() - 7, 50f, YAxis.AxisDependency.LEFT);

    }



    private LineDataSet createSet() {

        LineDataSet set = new LineDataSet(null, "Latency");
        set.setLineWidth(2.5f);
        set.setCircleRadius(4.5f);
        set.setColor(Color.rgb(240, 99, 99));
        set.setCircleColor(Color.rgb(240, 99, 99));
        set.setHighLightColor(Color.rgb(190, 190, 190));
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setValueTextSize(10f);

        return set;
    }
    private LineDataSet createSet2() {

        LineDataSet set = new LineDataSet(null, "Simulated Bluetooth latency");
        set.setLineWidth(2.5f);
        set.setCircleRadius(4.5f);
        set.setColor(Color.rgb(40, 99, 240));
        set.setCircleColor(Color.rgb(40, 99, 240));
        set.setHighLightColor(Color.rgb(190, 190, 190));
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setValueTextSize(10f);

        return set;
    }



}