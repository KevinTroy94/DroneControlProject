package com.example.joysticktest;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link graphFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class graphFragment extends Fragment {


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private SharedPreferences sharedPreferences;
    private LineChart chart;


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public graphFragment() {
        // Required empty public constructor
    }


    public static graphFragment newInstance(String param1, String param2) {
        graphFragment fragment = new graphFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        super.onCreate(savedInstanceState);


        return inflater.inflate(R.layout.fragment_graph, container, false);
    }


    private void addEntry(float input) {

        LineData data = chart.getData();

        if (data == null) {
            data = new LineData();
            chart.setData(data);
        }

        ILineDataSet set = data.getDataSetByIndex(0); //this is where to go if you want more lines
        // set.addEntry(...); // can be called as well

        if (set == null) {
            set = createSet();
            data.addDataSet(set);
        }

        // choose a random dataSet
        //int SetIndex = (int) data.getDataSetCount();
        ILineDataSet theSet = data.getDataSetByIndex(0);
        float value = (float) (input);

        data.addEntry(new Entry(theSet.getEntryCount(), value), 0);
        data.notifyDataChanged();

        // let the chart know it's data has changed
        chart.notifyDataSetChanged();

        chart.setVisibleXRangeMaximum(6);
        //chart.setVisibleYRangeMaximum(15, AxisDependency.LEFT);
//
//            // this automatically refreshes the chart (calls invalidate())
        chart.moveViewTo(data.getEntryCount() - 7, 50f, YAxis.AxisDependency.LEFT);

    }

    private LineDataSet createSet() {

        LineDataSet set = new LineDataSet(null, "Room Temperature");
        set.setLineWidth(2.5f);
        set.setCircleRadius(4.5f);
        set.setColor(Color.rgb(240, 99, 99));
        set.setCircleColor(Color.rgb(240, 99, 99));
        set.setHighLightColor(Color.rgb(190, 190, 190));
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        set.setValueTextSize(10f);

        return set;
    }

    @Override
    public void onStart() {
        super.onStart();
        chart = getActivity().findViewById(R.id.chart1);
        chart.setDrawGridBackground(false);
        chart.getDescription().setEnabled(false);
        chart.setNoDataText("Waiting for temperature Data");

        chart.invalidate();

        //sharedPreferences = getActivity().getSharedPreferences("tempData", Context.MODE_PRIVATE);
        //final float currentPress = Float.parseFloat(sharedPreferences.getString("tempData", null));
        Thread splashTread = new Thread() {

            public void run() {
                while (true) {


                    try {
                        sleep(4000);
                        //final float currentTemp = Float.parseFloat(tempData.getString("tempData", null));
                        addEntry(4000);
                        //change thing here

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }
        };
        splashTread.start();
    }
}