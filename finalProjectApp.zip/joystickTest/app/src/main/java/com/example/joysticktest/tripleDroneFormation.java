package com.example.joysticktest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.zerokol.views.joystickView.JoystickView;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import static java.lang.Thread.sleep;

public class tripleDroneFormation extends AppCompatActivity  implements MqttCallbackExtended {

    private JoystickView joystick;
    private final static String MQTT_HOST = "tcp://broker.emqx.io:1883"; //this is broker
    private final static String TOPICOUT = "droneCommand/value"; //topic
    private final static String TOPICIN = "droneCommand/value"; //topic
    private final static String TOPICTOGGLE = "droneCommand/Toggle"; //topic for toggling drones
    MqttAndroidClient androidClient;
    ImageView droneView1, droneView2, droneView3;
    boolean enabledDrone1 = true, enabledDrone2 = true, enabledDrone3 = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triple_drone_formation);


        droneView1 = findViewById(R.id.droneImage1);

        droneView2 = findViewById(R.id.droneImage2);

        droneView3 = findViewById(R.id.droneImage3);

        droneNuetral();

        //droneView3 = findViewById(R.id.droneImage3);

        String clientId = MqttClient.generateClientId(); //creates client id
        androidClient = new MqttAndroidClient(this,MQTT_HOST,clientId);

        //callback
        androidClient.setCallback(this);

        joystick = (JoystickView) findViewById(R.id.joystickView);

        //Event listener that always returns the variation of the angle in degrees, motion power in percentage and direction of movement
        joystick.setOnJoystickMoveListener(new JoystickView.OnJoystickMoveListener() {

            @Override
            public void onValueChanged(int angle, int power, int direction) {
                // TODO Auto-generated method stub
                //angleTextView.setText(" " + String.valueOf(angle) + "°");
                //powerTextView.setText(" " + String.valueOf(power) + "%");
                //this is what happens when the joystick is pulled
                String message;
                switch (direction) {
                    case JoystickView.FRONT:
                        //directionTextView.setText(R.string.front_lab);
                        message = "Moving up at : " + System.currentTimeMillis();
                        publish(TOPICOUT,message);
                        if(enabledDrone1){
                            droneView1.setImageResource(R.drawable.dronegoingforward);
                        }
                        if(enabledDrone2){
                            droneView2.setImageResource(R.drawable.dronegoingforward);
                        }
                        if(enabledDrone3){
                            droneView3.setImageResource(R.drawable.dronegoingforward);
                        }
                        droneNuetral();
                        break;
                    case JoystickView.FRONT_RIGHT:
                        //directionTextView.setText(R.string.front_right_lab);
                        break;
                    case JoystickView.RIGHT:
                        //directionTextView.setText(R.string.right_lab);
                        message = "Moving Left at : " + System.currentTimeMillis();
                        publish(TOPICOUT,message);
                        if(enabledDrone1){
                            droneView1.setImageResource(R.drawable.dronegoingleft);
                        }
                        if(enabledDrone2){
                            droneView2.setImageResource(R.drawable.dronegoingleft);
                        }
                        if(enabledDrone3){
                            droneView3.setImageResource(R.drawable.dronegoingleft);
                        }
                        droneNuetral();
                        break;
                    case JoystickView.RIGHT_BOTTOM:
                        //directionTextView.setText(R.string.right_bottom_lab);
                        break;
                    case JoystickView.BOTTOM:
                        //directionTextView.setText(R.string.bottom_lab);
                        message = "Moving Down at : " + System.currentTimeMillis();
                        if(enabledDrone1){
                            droneView1.setImageResource(R.drawable.dronegoingback);
                        }
                        if(enabledDrone2){
                            droneView2.setImageResource(R.drawable.dronegoingback);
                        }
                        if(enabledDrone3){
                            droneView3.setImageResource(R.drawable.dronegoingback);
                        }
                        publish(TOPICOUT,message);
                        droneNuetral();
                        break;
                    case JoystickView.BOTTOM_LEFT:
                        //directionTextView.setText(R.string.bottom_left_lab);
                        break;
                    case JoystickView.LEFT:
                        //directionTextView.setText(R.string.left_lab);
                        message = "Moving Right at : " + System.currentTimeMillis();
                        publish(TOPICOUT,message);
                        if(enabledDrone1){
                            droneView1.setImageResource(R.drawable.dronegoingright);
                        }
                        if(enabledDrone2){
                            droneView2.setImageResource(R.drawable.dronegoingright);
                        }
                        if(enabledDrone3){
                            droneView3.setImageResource(R.drawable.dronegoingright);
                        }
                        droneNuetral();
                        break;
                    case JoystickView.LEFT_FRONT:
                        break;
                    default:
                        //directionTextView.setText(R.string.center_lab);
                }
            }
        }, JoystickView.DEFAULT_LOOP_INTERVAL);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_proj, menu);
        return true;
    }

    public void droneNuetral() {
        Thread splashTread = new Thread() {
            public void run() {
                    try {
                        sleep(2000);
                        if(enabledDrone1){
                            droneView1.setImageResource(R.drawable.droneallgood);
                        }
                        if(enabledDrone2){
                            droneView2.setImageResource(R.drawable.droneallgood);
                        }
                        if(enabledDrone3){
                            droneView3.setImageResource(R.drawable.droneallgood);
                        }
                    } catch (Exception e) {
                        Log.d("CannotNuetral", "Cannot set drones to hover");
                    }
            }
        };
        splashTread.start();
    }

    public void toggleDrone1(View view){
        //toggles drone to respond to commands
        final MediaPlayer mpDrone = MediaPlayer.create(this, R.raw.powerdown);
        if(enabledDrone1){
            enabledDrone1 = false;
            droneView1.setImageResource(R.drawable.droneimage1); //set drone image to off
            publish(TOPICTOGGLE, ""+1);
            mpDrone.start();
        }
        else{
            enabledDrone1 = true;
            droneView1.setImageResource(R.drawable.droneallgood);
            publish(TOPICTOGGLE, ""+1);
        }
    }

    public void toggleDrone2(View view){
        //toggles drone to respond to commands
        final MediaPlayer mpDrone = MediaPlayer.create(this, R.raw.powerdown);
        if(enabledDrone2){
            enabledDrone2 = false;
            droneView2.setImageResource(R.drawable.droneimage1); //set drone image to off
            publish(TOPICTOGGLE, ""+2);
            mpDrone.start();
        }
        else{
            enabledDrone2 = true;
            droneView2.setImageResource(R.drawable.droneallgood);
            publish(TOPICTOGGLE, ""+2);
        }
    }

    public void toggleDrone3(View view){
        //toggles drone to respond to commands
        final MediaPlayer mpDrone = MediaPlayer.create(this, R.raw.powerdown);
        if(enabledDrone3){
            enabledDrone3 = false;
            droneView3.setImageResource(R.drawable.droneimage1); //set drone image to off
            publish(TOPICTOGGLE, ""+3);
            mpDrone.start();
        }
        else{
            enabledDrone3 = true;
            droneView3.setImageResource(R.drawable.droneallgood);
            publish(TOPICTOGGLE, ""+3);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.Main) {
            //Go Back to main activity
            Intent i = new Intent(this,MainActivity.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_right,R.transition.slide_out_left);

        }
        if (id == R.id.Latency) {
            Intent i = new Intent(this,Latency.class);
            startActivity(i);
            overridePendingTransition(R.transition.slide_in_right,R.transition.slide_out_left);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void connectComplete(boolean reconnect, String serverURI) {

    }

    @Override
    public void connectionLost(Throwable cause) {

    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        //will use
        //formationTV.setText(topic);
        if(topic.equals(TOPICIN)){

        }

    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }

    @Override
    protected void onPostResume(){
        super.onPostResume();
        connect();
    }

    private void connect(){
        //create MQTT CONNECTION OPTIONS
        MqttConnectOptions connectOptions = new MqttConnectOptions();
        connectOptions.setAutomaticReconnect(true);
        connectOptions.setCleanSession(true);
        //connectOptions.setPassword(); not necessary for testing
        //connectOptions.setUserName(); not necessary for testing
        connectOptions.setConnectionTimeout(3);
        connectOptions.setKeepAliveInterval(60);

        try {
            androidClient.connect(connectOptions, null, new IMqttActionListener(){
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    DisconnectedBufferOptions options = new DisconnectedBufferOptions();
                    options.setBufferEnabled(true);
                    options.setBufferSize(100);
                    options.setPersistBuffer(false);
                    options.setDeleteOldestMessages(false);
                    androidClient.setBufferOpts(options);
                    subscribe(TOPICIN);
                    //subscribe using topic
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //Print error message
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    private void subscribe(final String topic) {

        //this is the subscribe method, called on connect
        try {
            androidClient.subscribe(topic, 0, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //Log.d(TAG, "onSuccess: topic subscription : " + topic);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //Log.d(TAG, "onFailure: topic subscription : " + topic, exception);
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

    }
    private void publish(String topic, String stringMessage){
        MqttMessage message = new MqttMessage();
        message.setPayload(stringMessage.getBytes());

        try {
            androidClient.publish(topic, message);

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }


}
